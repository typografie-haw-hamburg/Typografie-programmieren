//DATEN DATEN DATEN
//WETTERDATEN
var table_wetter;
var table_steps;
var table_temp;
var table_cal;
var color_x;
var r;
var x_off;
var NOISE_SCALE;
var y_off;
var z_off;
var px_offset;
var vertices_amount;
var Z_SPEED;
var X_SPEED;
var Y_SPEED;
var color_speed;









//PRELOAD DER DATEN
function preload() {

table_wetter = loadTable("data/wetter_kommagetrennt.csv","csv","header");

table_steps =
loadTable("data/steps_kommagetrennt.csv", "csv", "header");

table_temp =
loadTable("data/temp_kommagetrennt.csv", "csv", "header");

table_cal =
loadTable("data/cal_kommagetrennt.csv","csv", "header");





}



function setup() {
       
            
    w = window.innerWidth;
    h = window.innerHeight;

    createCanvas(w, h);
    frameRate(30);
        //Farbe muss in Abhängigkeit von table_temp stehen.
        color_x = random(38.68,162.86);
        var rows_wetter = table_wetter.getRows();
        var rows_steps = table_steps.getRows();
        var rows_cal = table_cal.getRows();
        var rows_temp = table_temp.getRows();

        print(table_temp.getRowCount() + ' total rows in table');
        print(table_temp.getColumnCount() + ' total columns in table');
            
// VARIABLEN
            var steps = rows_steps[8].getNum("Steps");
            print(steps); //das funktioniert. 
            var clouds = rows_wetter[8].getNum("Clouds");
            print(clouds); //das klappt.
//          var sun = rows_wetter[1].getNum("Sunshine");
//          print(sun);//das klappt NICHT.
            var temp = rows_temp[8].getNum("Temp");
            print(temp); //das klappt. 
            var cal = rows_cal[8].getNum("Events");
            print(cal);//das klappt. 
            
            





// Hier wird die Größe des Kreises festgelegt! Muss in Abhängigkeit von table_cal stehen.
            r = map(cal, 0, 5, 0, 60);
            print(r);//das klappt.
//var r = (w < h) ? w / 3 : h / 3; // radius is a third of the smaller screen dimension <- gerade noch.





x_off = 1000;
y_off = 1000;
z_off = 1000;

//Runde Kanten
vertices_amount = 360;




px_offset = 100;    // amplitude
NOISE_SCALE = map(steps, 16000, 1000, 0, 80)//60;//map(steps, 16000, 20, 2, 30);;  // the higher the softer. Muss in Abhängigkeit von table_steps stehen.
print(NOISE_SCALE);//das klappt!





// Geschwindigkeit Gewaber
Z_SPEED = 0.01;
X_SPEED = 0.1;
Y_SPEED = 0.1;




var dom_fps = document.getElementById("fps");
var prevTime;
color_x = 1;
var color_speed = 1;





            
        }





function draw() {

//        print(frameRate());

    
  colorMode(HSB);

  // draw shape:
  push();
  translate(w/2, h/2);

  background(100, 100, 15);   // bg color, wenn man das ausstellt, bekommt man einen tollen effekt.

  noStroke();
  fill(color_x,35.35,83.81);    // color
  beginShape();

//Hier wird der Kreis gezeichnet
  for (var a=0; a<TWO_PI;a+=TWO_PI/vertices_amount) {
            var x = r*sin(a);
            var y = r*cos(a);

            var new_x = x + (
                        noise(
                ((x_off+x)/NOISE_SCALE),
                ((y_off+y)/NOISE_SCALE),
                       z_off) * px_offset * sin(a));

            var new_y = y + (
                        noise(
                ((x_off+x)/NOISE_SCALE),
                ((y_off+y)/NOISE_SCALE),
                       z_off) * px_offset * cos(a))
            vertex(new_x,new_y);
  }
  endShape();

  pop();


  // update NOISE offsets
  z_off += Z_SPEED;
  x_off += X_SPEED;
  y_off += Y_SPEED;
  color_x += color_speed;
//  if(color_x > 360) color_x -= 360;
  // FPS counter for debugging
//  if (typeof prevTime !== "undefined") {
//    var now = Date.now();
//    dom_fps.innerHTML = (Math.round(1000/(now-prevTime)));
//  }
//  prevTime = Date.now();
}




function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}