﻿#targetengine test
//alert('test');
//
//
for (var i=0; i<10; i++){
	$.writeln('doc_'+i);
	
}
$.writeln(cc);`
cc=NothingEnum.NOTHING;
//alert(0);
for (var i=0; i<10; i++){
	$.writeln(i);
	$.sleep(100);
}