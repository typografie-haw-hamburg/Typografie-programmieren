

 
var allBeziers = [];

var disp = ["R"];



// "Bildspiegel"
var marginX = 60;
var marginY = 50;
var startingX = marginX;
var startingY = marginY;


// minimale und maximale Linienanzahl
var iterationsMin = 50;
var iterationsMax = 300;  



function preload () {
 
  var characterJson = loadJSON("bezierjson.json");
  allBeziers.push(characterJson);
}



function setup() {

  createCanvas(windowWidth, windowHeight);
  frameRate(10);
}

function draw() {
 createCanvas( windowWidth, windowHeight );
 background(0);
 fill(255);

// Trigger
 var frames1 = random(100);
 var frames2 = random(100);

 
 startingPointX = [ marginX, width/ 2, width - marginX ];
 startingPointY = [ marginY, height - marginY ];
  
 
  // Anzahl der Loops (Linienanzahl)
 
  
  /*if ( frameCount % 100 === 0 ) {
   disp = CharactersReadyToDisp[round(random(CharactersReadyToDisp.length - 1))];
  }*/
  
  
 var size = 1;
 var X  = [];
 var Y = [];
 

 for (var k =0; k < disp.length; k ++) {
  
  var l = 0;
  
  if (disp.length === 2) {
   l = - 310 + (620 * k)
  }
  if (disp.length === 3) {
   l = -620 + (620 * k);
  }
  
  
  for ( var i = 0; i < allBeziers[0][disp[k]].length; i++ ) {
   
  
   iterationsMin = round( random( 0, 50 ));
   iterationsMax = round( random( 0, 50 ));
  
   for ( var j = 0; j < random( iterationsMin, iterationsMax); j++ ) {
    
    noStroke();
    var kurve = bzr( allBeziers[0][disp[k]][i].p0x*size+l, allBeziers[0][disp[k]][i].p0y*size, allBeziers[0][disp[k]][i].cp0x*size + l, allBeziers[0][disp[k]][i].cp0y*size, allBeziers[0][disp[k]][i].cp1x*size + l, allBeziers[0][disp[k]][i].cp1y*size, allBeziers[0][disp[k]][i].p1x*size+ l, allBeziers[0][disp[k]][i].p1y*size );
    var Pxi = kurve.Pxi;
    var Pyi = kurve.Pyi;
    
    X.push(Pxi);
    Y.push(Pyi);
  
    stroke(255);
   
    strokeWeight(0.2);
     startingX = startingPointX[k];
    
  if (X.length > 4) {
 
     bezier( X[0], Y[0], X[1], Y[1], X[2], Y[2], X[3], Y[3]);
     X.splice(0, X.length-2);
     Y.splice(0, Y.length-2);
     
    }
   

    
   // line( startingX, height - marginY, Pxi, Pyi );
    
    
   }

  }
 }
}


function bzr( p0x, p0y, cp0x, cp0y, cp1x, cp1y, p1x, p1y ) {
  
  noFill();
  
  var ti = random( 1 );
  
  var Axi = ((1 - ti) * p0x) + (ti * cp0x);
  var Ayi = ((1 - ti) * p0y) + (ti * cp0y);
  var Bxi = ((1 - ti) * cp0x) + (ti * cp1x);
  var Byi = ((1 - ti) * cp0y) + (ti * cp1y);
  var Cxi = ((1 - ti) * cp1x) + (ti * p1x);
  var Cyi = ((1 - ti) * cp1y) + (ti * p1y);
  
  var Dxi = ((1 - ti) * Axi) + (ti * Bxi);
  var Dyi = ((1 - ti) * Ayi) + (ti * Byi);
  var Exi = ((1 - ti) * Bxi) + (ti * Cxi);
  var Eyi = ((1 - ti) * Byi) + (ti * Cyi);
  
  // Punkt auf Bezier (entfernung in %(t) von p0)
  var Pxi = ((1 - ti) * Dxi) + (ti * Exi);
  var Pyi = ((1 - ti) * Dyi) + (ti * Eyi);
  
  bezier( p0x, p0y, cp0x, cp0y, cp1x, cp1y, p1x, p1y );
  
  var result = {
   Pxi: Pxi,
   Pyi: Pyi
  };
  return result;
  
 }

 

document.onkeypress = function(evt) {
  evt = evt || window.event;

  // Ensure we only handle printable keys
  var charCode = typeof evt.which == "number" ? evt.which : evt.keyCode;

  if (charCode || charCode != " ") {
   disp.push(String.fromCharCode(charCode));
   if (disp.length > 3) {
    disp.splice(0,1)
   }
  }
 if (charCode == " ") {
  disp.splice(0, disp.length)
 }
 
};
 