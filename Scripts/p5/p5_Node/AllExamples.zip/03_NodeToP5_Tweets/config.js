// Change this file to config.js
// Add your keys
// Add file .gitignore: config.js
// Load with
// var config = require('./config.js');

module.exports = {
  consumer_key:         'xQioRoAdDcC7yyipfsUlVmJA1',
  consumer_secret:      'ddIyzXu1Ro9TxRgXvuRKdLboECr8xgrF4T2eCVNvTOQwXW9J4v',
  access_token:         '816778715782901760-6uRto245Jcq51sQnazCuxvusZ4MK1vR',
  access_token_secret:  'IsZEaZfK6IJdowmvAjnWsCSH1TlQugm7sfGU25jBbyOVY',
  timeout_ms:           60*1000,  // optional HTTP request timeout to apply to all requests.
};