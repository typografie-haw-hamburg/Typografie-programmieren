// Change this file to config.js
// Add your keys
// Add file .gitignore: config.js
// Load with 
// var config = require('./config.js');

module.exports = {

  consumer_key:         '43OrGwbsfC8r56kjcf0p0dk1A',
  consumer_secret:      'PIs3bBiDEdYv5x6aKcsCe4wxejoovOzsVciL79lvjnHbCmTfw0',
  access_token:         '801202013371592704-mbwuUEHaQ1q0OXamq9CjPsRYR1cf9iJ',
  access_token_secret:  'BFPLAsoH6AS8pe3JDaNJmHkWisH9xim6EQ0S5gsznofSR',


}